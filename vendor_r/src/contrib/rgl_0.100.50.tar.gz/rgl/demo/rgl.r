# all rgl demos
demo(hist3d)
demo(abundance)
demo(regression)
demo(lsystem)
demo(subdivision)
# requires MASS library
demo(bivar)

