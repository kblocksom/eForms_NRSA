
#ifdef HAVE_FREETYPE

#include "FTBuffer.cpp"
#include "FTCharmap.cpp"
#include "FTFace.cpp"
#include "FTFont/FTFont.cpp"
#include "FTFont/FTBufferFont.cpp"
#include "FTFont/FTPixmapFont.cpp"
#include "FTGlyphContainer.cpp"
#include "FTGlyph/FTGlyph.cpp"
#include "FTGlyph/FTPixmapGlyph.cpp"
#include "FTGlyph/FTBufferGlyph.cpp"
#include "FTLibrary.cpp"
#include "FTSize.cpp"

#endif
